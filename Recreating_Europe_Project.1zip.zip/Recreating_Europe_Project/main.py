

# Global
CountryFilter = 'US'
SubCountFilter = 10000
SubPerPage = 5

def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')


def save_info(fileName, channelList):
    with open(fileName, 'w') as f:
        for item in channelList:
            f.write("%s\n" % item)
    return

# get channel info
def get_channel_info(youtube, channelId):

    try:
        ci = ChannelItem(channelId)

        request = youtube.channels().list(part="contentDetails,id,snippet,statistics",
                                          id=channelId)

        response = request.execute()

        if len(response['items']) <= 0:
            ci.Error = "No items in response"
            return ci

        country = (response['items'][0]['snippet']['country'])

        if country != CountryFilter:
            ci.Error = "Filtered by country"
            return ci

        subCountStr = (response['items'][0]['statistics']['subscriberCount'])
        subCount = int(subCountStr)

        if subCount < SubCountFilter:
            ci.Error = "Filtered by sub count"
            return ci

        ci.Error = None
        ci.Title = response['items'][0]['snippet']['title']
        ci.Country = country
        ci.PublishedAt = response['items'][0]['snippet']['publishedAt']
        ci.SubCount = subCount

    except BaseException as err:
        ci.Error = err

    return ci

# get subs info
def get_sub_ids(youtube, channelId):

    all_data = []

    request = youtube.subscriptions().list(part="contentDetails,id,snippet,subscriberSnippet",
                                           channelId=channelId, maxResults=SubPerPage,
                                           order="subscriptionOrderUnspecified")
    response = request.execute()

    for i in range(len(response['items'])):
        all_data.append(response['items'][i]['snippet']['resourceId']['channelId'])

    nextPageToken = response.get('nextPageToken')

    while nextPageToken is not None:
        request = youtube.subscriptions().list(part="contentDetails,id,snippet,subscriberSnippet",
                                               channelId=channelId, maxResults=SubPerPage,
                                               order="subscriptionOrderUnspecified",
                                               pageToken=nextPageToken)
        response = request.execute()

        for i in range(len(response['items'])):
            all_data.append(response['items'][i]['snippet']['resourceId']['channelId'])

        nextPageToken = response.get('nextPageToken')

    return all_data


api_key = #yourapikey

youtube = build('youtube', 'v3', developerKey=api_key)

visited = set()
#visited.add('UCDmbhGe7-wC1a55l5ZYAZJw')
#visited.add('UCwwr32_qOAG1x12p2072i6g')

q = queue.Queue()


#q.put('UCDmbhGe7-wC1a55l5ZYAZJw')

#test channel
q.put('UCJhGlQTGHsS92iIvpFlRiYA')

channelList = list()
channelSubList = list()

#ss = ChannelItem("asd")
#channelList.append(ss)
#save_channel_info(channelList)

while not q.empty():
    channelId = q.get()

    if channelId in visited:
        continue

    try:
        channelItem = get_channel_info(youtube, channelId)
        channelList.append(channelItem)

        # mark as visited
        visited.add(channelId)

        if channelItem is None or channelItem.Error is not None:
            continue

        try:
            subIds = get_sub_ids(youtube, channelId)

            for subId in subIds:
                subItem = SubItem(channelId, subId)
                channelSubList.append(subItem)
                q.put(subId)
        except BaseException as subErr:
            subItem = SubItem(channelId, subId)
            subItem.Error = subErr
            channelSubList.append(subItem)

    except BaseException as err:
        print(f"Unexpected {err=}, {type(err)=}")
else:
    print('done')

if q.empty():
    print('Nothing is left')

# save
try:
    save_info('channels.txt', channelList)

except BaseException as err:
    print(f"Unexpected {err=}, {type(err)=}")

try:
    save_info('channel_subs.txt', channelSubList)

except BaseException as err:
    print(f"Unexpected {err=}, {type(err)=}")
