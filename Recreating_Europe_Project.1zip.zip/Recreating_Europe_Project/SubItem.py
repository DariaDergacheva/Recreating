class SubItem:
    def __init__(self, sourceId, subId):
        self.SourceId = sourceId
        self.SubId = subId
        self.Error = None

    def __str__(self):
        return "{},{},{}".format(self.SourceId, self.SubId, self.Error)
