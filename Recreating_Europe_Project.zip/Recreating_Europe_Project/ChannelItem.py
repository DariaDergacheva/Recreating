class ChannelItem:
    def __init__(self, id):
        self.Id = id
        self.Title = None
        self.Country = "";
        self.PublishedAt = ""
        self.SubCount = 0
        self.Error = None

    def __str__(self):
        return "{},{},{},{},{},{}".format(self.Id, self.Title, self.Country, self.PublishedAt, self.SubCount, self.Error)
